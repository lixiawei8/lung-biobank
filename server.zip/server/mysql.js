const mysql = require('mysql')


const client = mysql.createConnection({
  host: 'localhost',
  port: 3306,
  user: 'root',
  password: 'password',
  database: 'lung_DB'
})

function sqlFun (sql, arr, callback) {
  client.query(sql, arr, function (error, result) {
    if (error) {
      console.log('sqlFun执行错误', error)
    } else {
      // console.log('sqlFun执行成功', JSON.stringify(result))
      console.log('sqlFun执行成功')
    }
    callback(result)
  })
}

module.exports = sqlFun
