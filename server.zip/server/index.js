const express = require('express')
const app = express()


app.use(express.urlencoded({ extended: true }))
// 静态文件托管
app.use(express.static('upload'))

app.get('/', (req, res) => {
  res.send('hello Vue2')
})

const router = require('./router')
app.use('/', router)

app.listen(7788, () => {
  console.log("mysql running on http://localhost:7788")
}) 
