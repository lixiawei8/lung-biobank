const express = require('express')
const router = express.Router()
const sqlFun = require('./mysql')
const multer = require('multer')
const fs = require('fs')
const dayjs = require('dayjs')


const serverDir = '/Users/apple/wlx/code/PLU_platform/vue-lung-platform/server'

// 模型列表接口，参数: category
router.get('/models/modelList', (req, res) => {
  console.log('------------server router, modelList')
  const category = req.query.category
  const sql = `select * from muldata where category='${category}'`
  console.log('------------server router sql:', sql)

  sqlFun(sql, null, (result) => {
    if (result.length > 0) {
      res.send({
        status: 200,
        data: result,
        pageSize: 100,
        total: result.length // 记录总条数
      })
    } else {
      res.send({
        status: 500,
        msg: '暂无数据'
      })
    }
  })
})

// 查询接口，参数: modelId, modelName
router.get('/models/search', (req, res) => {
  console.log('----search server router ')
  const modelId = req.query.modelId
  const modelKey = req.query.modelKey
  let sql
  if (modelId) {
    sql = `select * from muldata where id='${modelId}'`
  } else {
    sql = `select * from muldata where concat(name, category, feature, description) like '%${modelKey}%'`
  }
  console.log('-----------server router, sql:', sql)
  sqlFun(sql, null, (result) => {
    if (result.length > 0) {
      res.send({
        status: 200,
        data: result,
        pageSize: 100,
        total: result.length // 记录总条数
      })
    } else {
      res.send({
        status: 500,
        msg: '暂无数据'
      })
    }
  })
})

// 删除单模型记录接口 id
router.get('/models/deleteItemById', (req, res) => {
  console.log('----deleteItemById server router ')
  const id = req.query.id
  const sql = 'delete from muldata where id=?'
  const arr = [id]
  sqlFun(sql, arr, (result) => {
    if (result.affectedRows > 0) {
      res.send({
        status: 200,
        msg: '删除成功'
      })
    } else {
      res.send({
        status: 500,
        msg: '删除失败'
      })
    }
  })
})

// 批量删除模型记录接口 ids: []
router.get('/models/deleteItemByIds', (req, res) => {
  const ids = req.query.ids
  console.log('------------------deleteItemByIds, ids', ids)
  const sql = `delete from muldata where id in (${ids})`

  sqlFun(sql, null, (result) => {
    if (result.affectedRows > 0) {
      res.send({
        status: 200,
        msg: '批量删除成功'
      })
    } else {
      res.send({
        status: 500,
        msg: '批量删除失败'
      })
    }
  })
})

// 添加单模型记录接口
/* 参数:  name, category, feature, description, code, scriptPath, dataPath, imagePath
*/
router.get('/models/item/insertItem', (req, res) => {
  console.log('----------insertItem server router, req.query', req.query)
  const name = req.query.name || ''
  const category = req.query.category || ''
  // const feature = req.query.feature || ''
  const description = req.query.description || ''
  const codeStr = req.query.codeStr || ''
  // const scriptPath = req.query.scriptPath || '' // 传入字符串
  const dataPath = req.query.dataPath || ''

  const dateStr = new Date()
  const createTime = dayjs(dateStr).format('YYYY-MM-DD HH:mm:ss')

  // id 可自动增加
  // const sql = `insert into muldata(name, category, createTime, feature, description, code, scriptPath, dataPath) values ('${name}', '${category}', '${createTime}', '${feature}', '${description}', '${code}', '${scriptPath}', '${dataPath}')`
  const sql = `insert into muldata(name, category, createTime, description, codeStr, dataPath) values ('${name}', '${category}', '${createTime}', '${description}', '${codeStr}', '${dataPath}')`

  sqlFun(sql, null, (result) => {
    if (result.affectedRows > 0) {
      res.send({
        status: 200,
        msg: '添加成功'
      })
    } else {
      res.send({
        status: 500,
        msg: '添加失败'
      })
    }
  })
})

// 修改模型记录接口
/* 参数: id
*/
router.get('/models/item/updateItem', (req, res) => {
  console.log('----------updateItem server router, req.query', req.query)

  const id = req.query.id || ''
  const name = req.query.name || ''
  const category = req.query.category || ''
  // const feature = req.query.feature || ''
  const description = req.query.description || ''
  const codeStr = req.query.codeStr || ''
  // const scriptPath = req.query.scriptPath || '' // 传入字符串
  const dataPath = req.query.dataPath || ''
  const sql = `update muldata set name='${name}', category='${category}', description='${description}', codeStr='${codeStr}', dataPath='${dataPath}' where id = '${id}'`
  console.log("----- sql", sql)

  /// 
    // sql = `select * from muldata where id='${modelId}'`

  // const id = req.query.id
  // const sql = 'delete from muldata where id=?'
  // const arr = [id]
  // sqlFun(sql, arr, (result) => {
  //   ///
  // const arr = [name, category, feature, description, code, scriptPath, dataPath, id]
  const arr = [name, category, description, codeStr, dataPath, id]
  sqlFun(sql, arr, (result) => {
    if (result.affectedRows > 0) {
      res.send({
        status: 200,
        msg: '修改成功'
      })
    } else {
      res.send({
        status: 500,
        msg: '修改失败'
      })
    }
  })
})

/*
  上传 post请求
*/
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, './upload')
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '-' + file.originalname)
  }
})

const createFolder = function (folder) {
  try {
    fs.accessSync(folder)
  } catch (e) {
    fs.mkdirSync(folder)
  }
}
const uploadFolder = './upload'
createFolder(uploadFolder)
const upload = multer({
  storage: storage
})
// 传图接口，参数
router.post('/upload', upload.single('file'), function (req, res, next) {
  const file = req.file
  console.log('----文件类型: %s', file.mimetype, ', 文件原始名: %s', file.originalname)
  console.log('----文件大小: %s', file.size, ', 文件保存路径: %s', file.path)
  res.json({
    res_code: '200',
    name: file.originalname,
    url: file.path
  })
})

// 执行py语句
router.get('/models/execCode', (req, res) => {
  console.log(`-------nice done --- router req.query.codeStr: ${req.query.codeStr}`)
  const codeStr = req.query.codeStr
  const { spawn } = require('child_process')

  const pythonProcess = spawn('python3', ['-c', codeStr])
  pythonProcess.stdout.on('data', (data) => {
    console.log(`---------- router Python语句的标准输出: ${data}`)
    res.send({
      status: 200,
      result: data.toString()
    })
  })
  pythonProcess.stderr.on('data', (data) => {
    console.error(`---------- router Python语句的err输出: ${data}`)
    res.send({
      status: 500,
      result: data.toString()
    })
  })

  // 注意：当Python进程结束时，会触发'close'事件
  pythonProcess.on('close', (code) => {
    console.log(`Python process exited with code ${code}`)
  })
})

// 执行py文件
router.get('/models/execScript', (req, res) => {
  const file = serverDir + '/' + req.query.pythonFPath
  const task = req.query.task

  let modelFPath
  if (req.query.modelFPath.indexOf(',') === -1) {
    modelFPath = serverDir + '/' + req.query.modelFPath
  } else {
    const modelList = req.query.modelFPath.split(',')
    modelFPath = serverDir + '/' + modelList[0] + ',' + serverDir + '/' + modelList[1]
  }

  let thirdParam
  if (task.indexOf('singleRecognition') !== -1) {
    thirdParam = serverDir + '/' + req.query.thirdParam
  } else {
    thirdParam = req.query.thirdParam
  }
  const { exec } = require('child_process')
  const command = `python ${file} ${modelFPath} ${task} ${thirdParam}`
  console.log(`---------- router command: ${command}`)

  exec(command, (error, stdout, stderr) => {
    if (error) {
      console.error(`-------------执行Python文件时出错:${error}`)
      res.send({
        status: 500,
        result: error.toString()
      })
    } else {
      res.send({
        status: 200,
        result: stdout.toString()
      })
    }
  })
})

// read文件
router.get('/models/readFile', (req, res) => {
  const fpath = req.query.fpath
  // nodejs中强烈建议使用绝对路径，使用相对路径拼接的过程中，会以终端的位置进行拼接，从而导致找不到文件
  fs.readFile(fpath, 'utf8', function (error, dataStr) {
    if (error) {
      res.send({
        status: 500,
        result: error.toString()
      })
      return
    }
    res.send({
      status: 200,
      result: dataStr
    })
  })
})

// ///
// router.get('/users', (req, res) => {
//   const sql = `select * from user`
//   sqlFun(sql, null, (result) => {
//       res.send({
//         status: 200,
//         msg: '查找成功',
//         result: result,
//         token: '21232f297a57a5a743894a0e4a801fc3'
//       })
//   })
// })
// /

// 登录  username, pwd
router.get('/login', (req, res) => {
  const username = req.query.user
  const pwd = req.query.pwd
  const sql = `select * from user where username='${username}' and password='${pwd}'`

  console.log('---------- login, server router, username:', username, ' , pwd:', pwd)
  sqlFun(sql, null, (result) => {
    if (result.length > 0) {
      res.send({
        status: 200,
        msg: '登录成功',
        result: result,
        token: '21232f297a57a5a743894a0e4a801fc3'
      })
    } else {
      res.send({
        status: 500,
        msg: '用户名或密码错误'
      })
    }
  })
})

// 改密  id, pass
router.get('/changePwd', (req, res) => {
  const id = req.query.id
  const pass = req.query.pass

  const sql = 'update user set password=? where id=?'
  const arr = [pass, id]
  sqlFun(sql, arr, (result) => {
    if (result.affectedRows > 0) {
      res.send({
        status: 200,
        msg: '密码修改成功'
      })
    } else {
      res.send({
        status: 500,
        msg: '密码修改失败'
      })
    }
  })
})

module.exports = router
