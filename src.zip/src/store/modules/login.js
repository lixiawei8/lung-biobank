/*
  存储登录信息
*/
export default {
  namespaced: true,
  state: {
    userInfo: {
      id: '',
      uname: '',
      pword: '',
      token: ''
    } // 仓库中初始为空
  },
  mutations: {
    // 登录设置用户信息
    setUser (state, payload) {
      state.userInfo = payload
    },
    // 退出清空数据
    removeUserInfo (state, payload) {
      state.userInfo = {
        id: '',
        uname: '',
        pword: '',
        token: ''
      }
    }
  }
}
