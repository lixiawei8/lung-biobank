/*
  存储数据信息
*/
export default {
  namespaced: true,
  state: {
    title: '添加', // 标题信息
    newData: {} // 仓库中初始为空
  },
  mutations: {
    changeTitle (state, title) {
      state.title = title
    },
    changeData (state, data) {
      state.newData = data
    }
  }
}
