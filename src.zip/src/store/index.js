import Vue from 'vue'
import Vuex from 'vuex'
import model from './modules/model'
import login from './modules/login'
import createPersistedstate from 'vuex-persistedstate'
Vue.use(Vuex)

export default new Vuex.Store({
  state: {
  },
  getters: {
  },
  mutations: {
  },
  actions: {
  },
  modules: {
    model,
    login
  },
  plugins: [ // vuex插件
    createPersistedstate({
      key: 'info',
      paths: ['model', 'login'] // 存储的模块名称，全局state
    })
  ]
})
