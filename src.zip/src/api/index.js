import base from './base'
import axios from 'axios'

const api = {
  // 列表 不分页
  modelList (params) {
    return axios.get(base.modelList, { params })
  },

  // 搜索接口
  search (params) {
    return axios.get(base.search, { params })
  },

  // deleteItemById接口
  // id
  deleteItemById (params) {
    return axios.get(base.deleteItemById, { params })
  },

  // deleteItemByIds接口
  // ids数组
  deleteItemByIds (params) {
    return axios.get(base.deleteItemByIds, { params })
  },

  // insert接口
  // name, category, feature, description, code, scriptPath, modelPath, imagePath
  insertItem (params) {
    return axios.get(base.insertItem, { params })
  },

  // update接口
  // id; name, category, feature, description, code, scriptPath, modelPath, imagePath
  updateItem (params) {
    return axios.get(base.updateItem, { params })
  },

  // 执行python语句接口
  execCode (params) {
    console.log('---------- src/api index js params', params)
    console.log('---------- src/api index js base.execCode', base.execCode)
    const ret = axios.get(base.execCode, { params })
    return ret
  },

  // 执行python文件接口
  execScript (params) {
    const ret = axios.get(base.execScript, { params })
    return ret
  },

  // read文件接口
  readFile (params) {
    const ret = axios.get(base.readFile, { params })
    return ret
  },

  // 登录   // post则传参数直接写params；此处为get
  /*
  user, pwd
  */
  login (params) {
    return axios.get(base.login, { params })
  },

  // 改密
  /*
  id, pass
  */
  changePwd (params) {
    return axios.get(base.changePwd, { params })
  }
}
export default api
