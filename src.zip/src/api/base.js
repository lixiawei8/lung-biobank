const base = {
  // 数据管理
  modelList: '/api/models/modelList', // 列表
  search: '/api/models/search', // 搜索 by id/name
  deleteItemById: '/api/models/deleteItemById', // 删除 id
  deleteItemByIds: '/api/models/deleteItemByIds', // 批量删除 ids
  uploadUrl: '/api/upload', // upload
  insertItem: '/api/models/item/insertItem', // 添加
  updateItem: '/api/models/item/updateItem', // 修改 id

  // 任务执行
  execCode: '/api/models/execCode', // execCode
  execScript: '/api/models/execScript', // execScript
  readFile: '/api/models/readFile', // readFile

  login: '/api/login', // login  user, pwd  --get请求
  changePwd: '/api/changePwd' // changePwd  id, pass  --get请求
}

// 单一导出
export const host = 'http://localhost:7788'
export const uploadUrl = '/api/upload' // 图片上传地址
export default base
