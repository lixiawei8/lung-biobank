<template>
  <div>
    <el-upload
      :action="uploadUrl"
      accept=".png, .jpg, .jpeg"
      list-type="picture-card"
      :on-preview="handlePictureCardPreview"
      :on-remove="handleRemove"
      :on-success="handleSucc"
      :file-list="imList"
      ref="upload"
      multiple>
      <i class="el-icon-plus"></i>
    </el-upload>
  </div>
</template>

<script>
import { uploadUrl, host } from '@/api/base'
export default {
  props: {
    imList: { // 上传文件列表 [{url:""}]; 接收他人传送的list
      type: Array,
      default: function () {
        return []
      }
    }
  },
  data () {
    return {
      uploadUrl
    }
  },
  methods: {
    handleSucc (response, file, fileList) {
      const fname = response.url.slice(7)
      this.$emit('sendImg', fname) // 发出参数让组件使用者接收
    },
    handleRemove (file, fileList) {
      let imgUrl = ''
      if ('response' in file) {
        const url = file.response.url.slice(7)
        imgUrl = host + '/' + url
      } else {
        imgUrl = file.url
      }
      this.$emit('removeImg', imgUrl)
    },
    handlePictureCardPreview (file) {
      this.dialogImageUrl = file.url
      this.dialogVisible = true
    },
    // 清空图片列表展示
    clear () {
      console.log('--------清空图片列表展示')
      this.$refs.upload.clearFiles()
    }
  }
}
</script>
<style>
</style>
