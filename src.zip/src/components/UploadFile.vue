<template>
  <div>
    <el-upload
      :action="uploadUrl"
      accept=".py, .pth, .pt, .txt"
      :on-preview="handlePreview"
      :on-remove="handleRemove"
      :on-success="handleSucc"
      :file-list="fileList"
      ref="upload"
      multiple>
      <el-button size="small" type="primary">选择文件</el-button>
    </el-upload>
  </div>
</template>

<script>
import { uploadUrl, host } from '@/api/base'
export default {
  props: {
    fileList: { // 上传文件列表 [{url:""}]; 接收他人传送的list
      type: Array,
      default: function () {
        return []
      }
    }
  },
  data () {
    return {
      uploadUrl
    }
  },
  methods: {
    handleSucc (response, file, fileList) {
      const fname = response.url.slice(7)
      this.$emit('sendFile', fname) // 发出参数让组件使用者接收
    },
    handlePreview (file) {
      console.log('-----------handlePreview', file)
    },
    handleRemove (file, fileList) {
      let fileUrl = ''
      if ('response' in file) {
        const url = file.response.url.slice(7)
        fileUrl = host + '/' + url
      } else {
        fileUrl = file.url
      }
      this.$emit('removeFile', fileUrl)
    },

    // 清空file列表展示
    clear () {
      console.log('--------清空file列表展示')
      // this.fileList = []
      this.$refs.upload.clearFiles() // 与上述置空等效
    }
  }
}
</script>
<style>
</style>
