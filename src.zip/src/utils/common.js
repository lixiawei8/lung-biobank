export function removeHTMLTag (htmlStr) {
  const html = htmlStr
    .replace(/<img.*?>/g, '[图片]')
    .replaceAll(/<[^>]+>/g, '')
    .replace(/&nbsp;/gi, '')
  return html
}
