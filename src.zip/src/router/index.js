import Vue from 'vue'
import VueRouter from 'vue-router'
import MyLayout from '@/views/layout/Index.vue'
import MyHome from '@/views/home/Home.vue'
import store from '@/store'


const MyClinical = () => import('@/views/clinical/Index.vue')
const MyClinicalList = () => import('@/views/clinical/list/Index.vue')
const MyClinicalPage = () => import('@/views/clinical/list/Page.vue')
const MyClinicalRun = () => import('@/views/clinical/list/Run.vue')
const MyClinicalPerf = () => import('@/views/clinical/perf/Index.vue')
const MyClinicalVisual = () => import('@/views/clinical/visual/Index.vue')

const MyImaging = () => import('@/views/imaging/Index.vue')
const MyImagingList = () => import('@/views/imaging/list/Index.vue')
const MyImagingPage = () => import('@/views/imaging/list/Page.vue')
const MyImagingRun = () => import('@/views/imaging/list/Run.vue')
const MyImagingPerf = () => import('@/views/imaging/perf/Index.vue')
const MyImagingVisual = () => import('@/views/imaging/visual/Index.vue')

const MyGene = () => import('@/views/gene/Index.vue')
const MyGeneList = () => import('@/views/gene/list/Index.vue')
const MyGenePage = () => import('@/views/gene/list/Page.vue')
const MyGeneRun = () => import('@/views/gene/list/Run.vue')
const MyGenePerf = () => import('@/views/gene/perf/Index.vue')
const MyGeneVisual = () => import('@/views/gene/visual/Index.vue')

const MyPathology = () => import('@/views/pathology/Index.vue')
const MyPathologyList = () => import('@/views/pathology/list/Index.vue')
const MyPathologyPage = () => import('@/views/pathology/list/Page.vue')
const MyPathologyRun = () => import('@/views/pathology/list/Run.vue')
const MyPathologyPerf = () => import('@/views/pathology/perf/Index.vue')
const MyPathologyVisual = () => import('@/views/pathology/visual/Index.vue')

const MyLogin = () => import('@/views/login/Index.vue')
const MyChangePwd = () => import('@/views/system/changePwd/Index.vue')
Vue.use(VueRouter)


// this.$route.matched遍历数组
const routes = [
  {
    path: '/',
    component: MyLayout,
    meta: {
      title: '首页',
      isLogin: true
    },
    children: [
      {
        path: '/',
        name: 'home',
        component: MyHome
      },
      // 临床数据管理
      {
        path: '/clinical',
        name: 'Clinical',
        component: MyClinical,
        children: [
          {
            path: 'list', // 不能加"/"
            name: 'ClinicalList',
            component: MyClinicalList
          },
          {
            path: 'page', // 添加 编辑
            name: 'ClinicalPage',
            component: MyClinicalPage
          },
          {
            path: 'run', // 详情 运行
            name: 'ClinicalRun',
            component: MyClinicalRun
          },
          {
            path: 'perf', // 性能指标
            name: 'ClinicalPerf',
            component: MyClinicalPerf
          },
          {
            path: 'visual', // 可视化
            name: 'ClinicalVisual',
            component: MyClinicalVisual
          }
        ]
      },
      // 影像数据管理
      {
        path: '/imaging',
        name: 'Imaging',
        component: MyImaging,
        children: [
          {
            path: 'list', // 不能加"/"
            name: 'ImagingList',
            component: MyImagingList
          },
          {
            path: 'page', // 添加 编辑
            name: 'ImagingPage',
            component: MyImagingPage
          },
          {
            path: 'run', // 详情 运行
            name: 'ImagingRun',
            component: MyImagingRun
          },
          {
            path: 'perf', // 性能指标
            name: 'ImagingPerf',
            component: MyImagingPerf
          },
          {
            path: 'visual', // 可视化
            name: 'ImagingVisual',
            component: MyImagingVisual
          }
        ]
      },
      // 基因数据管理
      {
        path: '/gene',
        name: 'Gene',
        component: MyGene,
        children: [
          {
            path: 'list',
            name: 'GeneList', // 名称不要重复
            component: MyGeneList
          },
          {
            path: 'page',
            name: 'GenePage',
            component: MyGenePage
          },
          {
            path: 'run',
            name: 'GeneRun',
            component: MyGeneRun
          },
          {
            path: 'perf',
            name: 'GenePerf',
            component: MyGenePerf
          },
          {
            path: 'visual',
            name: 'GeneVisual',
            component: MyGeneVisual
          }
        ]
      },
      // 病理数据管理
      {
        path: '/pathology',
        name: 'Pathology',
        component: MyPathology,
        children: [
          {
            path: 'list',
            name: 'PathologyList',
            component: MyPathologyList
          },
          {
            path: 'page',
            name: 'PathologyPage',
            component: MyPathologyPage
          },
          {
            path: 'run',
            name: 'PathologyRun',
            component: MyPathologyRun
          },
          {
            path: 'perf',
            name: 'PathologyPerf',
            component: MyPathologyPerf
          },
          {
            path: 'visual',
            name: 'PathologyVisual',
            component: MyPathologyVisual
          }
        ]
      },
      {
        path: '/changePwd',
        name: 'changePwd',
        component: MyChangePwd,
        meta: {
          title: '修改密码'
        }
      }
    ]
  },
  {
    path: '/login',
    name: 'login',
    component: MyLogin
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

// 配置路由守卫导航
router.beforeEach((to, from, next) => {
  // 判断当前页面是否需要登录
  if (to.matched.some(ele => ele.meta.isLogin)) {
    // 是否已登录
    if (store.state.login.userInfo.token) { // token有值
      next()
    } else {
      next('/login') // 没有登录则登录
    }
  } else {
    next()
  }
})

export default router
