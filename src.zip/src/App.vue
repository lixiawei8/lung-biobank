<template>
  <div id="app">
    <!-- <span>我是app页</span> -->
    <router-view></router-view>
  </div>
</template>

<!-- 代码高亮
<script src="https://unpkg.com/prismjs/components/prism-core.min.js"></script>
<script src="https://unpkg.com/prismjs/components/prism-clike.min.js"></script>
<script src="https://unpkg.com/prismjs/components/prism-javascript.min.js"></script>
<script src="https://unpkg.com/prismjs/components/prism-html.min.js"></script> -->
<!-- /* 引入 Prism.js 的默认样式 */ -->
<!-- <link href="https://unpkg.com/prismjs/themes/prism.css" rel="stylesheet" /> -->

<script>
export default {
  name: 'app'
}
</script>
