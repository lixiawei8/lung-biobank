<template>
  <div class="home">
    <!-- 顶部区域布局 -->
    <div class="header">
      <div class="item">
        <div class="item-center">
          总患者数
          <div class="num">{{ 200000 | num }}</div>
        </div>
      </div>
      <div class="item">
        <div class="item-up">
          总检索量
          <div class="num">{{ 200 | num }}</div>
          <div class="bottom">今日检索量: {{ 200 | num }}</div>
        </div>
      </div>
    </div>

    <!-- 访问数据统计 -->
    <div class="content">
      <div class="chart">
          <div>示例模型性能
          </div>
          <div id="charts" style="width: 500px; height: 300px"></div>
        </div>
      <div class="chart">
        <div>各类模型比例（示例）
        </div>
        <div id="pie" style="width: 500px; height: 300px"></div>
      </div>
    </div>

    <!-- 最新内容 -->
    <div class="home-footer">
      <el-card class="box-card">
        <div slot="header" class="clearfix">
          <span>今日运行（示例）</span>
        </div>
        <div class="item-bottom">
          <el-row class="span-pad">
            <el-col :span="12">
              <!-- <div>{{ orderData.curOrderCount }}</div> -->
              <div class="title">今日记录数</div>
              <div class="num">{{ 10 | num }}</div>
            </el-col>
            <el-col :span="12">
              <!-- <div>{{ orderData.curCollect }}</div> -->
              <div class="title">错误记录</div>
              <div class="num">{{ 0 | num }}</div>
            </el-col>
          </el-row>
        </div>
      </el-card>
      <el-card class="box-card">
        <div slot="header" class="clearfix">
          <span>本月运行（示例）</span>
        </div>
        <div class="item-bottom">
          <el-row class="span-pad">
            <el-col :span="12">
              <div class="title">本月记录数</div>
              <div class="num">{{ 5000 | num }}</div>
            </el-col>
            <el-col :span="12">
              <div class="title">汇总错误记录</div>
              <div class="num">{{ 0 | num }}</div>
            </el-col>
          </el-row>
        </div>
      </el-card>
      <!-- <el-card class="box-card-fast">
        <div slot="header" class="clearfix">
          <span>快捷入口</span>
        </div> -->
      <!-- </el-card> -->
    </div>

  </div>
</template>

<script>
import * as echarts from 'echarts'
export default {
  name: 'MyHome',
  data () {
    return {
      totalData: {}, // 首页数据统计
      orderData: {} // 首页订单信息
    }
  },
  created () {
  },
  mounted () { // 最早获取DOM元素的生命周期函数，挂载完毕; 【静态需要, 动态不需要】
    // console.log('mounted-id', document.getElementById('charts'))
    this.line()
    this.pie()
  },
  methods: {
    // // 获取数据统计信息
    // async totalInfo () {
    //   const res = await this.$api.totalInfo()
    //   console.log('首页统计信息---', res.data.data.list)
    //   this.totalData = res.data.data.list
    // },
    // // 获取今日订单数据
    // async orderInfo () {
    //   const res = await this.$api.orderInfo()
    //   console.log('今日订单信息---', res.data)
    //   this.orderData = res.data.list
    // },
    // // 获取图表数据
    // async format () {
    //   const res = await this.$api.format()
    //   console.log('获取图表数据---', res.data.result.data.sale_money)
    //   // console.log(res.data.result.data.sale_money)
    //   // 获取x-axis名称
    //   const arr = res.data.result.data.sale_money
    //   const arrx = []
    //   const saleMoney = []
    //   const saleTotal = []
    //   const pieData = []
    //   arr.forEach(ele => {
    //     arrx.push(ele.name)
    //     saleTotal.push(ele.num)
    //     saleMoney.push(ele.total_amount)
    //     // 饼图数据
    //     const obj = {}
    //     obj.name = ele.name
    //     obj.value = ele.total_amount
    //     pieData.push(obj)
    //   })
    //   // console.log('arrx', arrx)
    //   // console.log('saleTotal', saleTotal)
    //   // console.log('saleMoney', saleMoney)
    //   this.line(arrx, saleTotal, saleMoney)
    //   this.pie(pieData)
    // },
    // 绘制图表
    line (data, saleTotal, saleMoney) {
      // 基于准备好的dom，初始化echarts实例
      const myChart = echarts.init(document.getElementById('charts'))
      // 绘制图表
      myChart.setOption({
        legend: {
        },
        tooltip: {
          // 提示框
          trigger: 'axis'
          // formatter: '{a}-{b}-{c}'
        },
        toolbox: {
          show: true,
          feature: {
            dataView: { readOnly: false },
            magicType: { type: ['line', 'bar'] },
            restore: {},
            saveAsImage: {}
          }
        },
        xAxis: { // x轴数据
          data: ['model1', 'model2', 'model3', 'model4', 'model5', 'model6'],
          // data,
          // axisLine: {
          //   lineStyle: {
          //     color: 'skyblue' // 坐标轴线颜色
          //   }
          // },
          axisTick: {
            alignWithLabel: true // 坐标轴刻度对齐
          }
        },
        yAxis: {},
        series: [
          {
            name: 'AUROC',
            type: 'bar',
            data: [76, 59, 65, 95, 64, 78]
            // data: saleTotal
          },
          {
            name: 'AUPRC',
            type: 'line', // bar 柱状图 line折线图  pie饼图 map地图
            data: [54, 88, 66, 89, 60, 59],
            // data: saleMoney,
            // label: {
            //   show: true
            // },
            // labelLine: {
            //   lineStyle: {
            //     color: '#ff5555'
            //   }
            // },
            // itemStyle: {
            //   color: '#ff5555'
            // },
            // lineStyle: {
            //   color: '#ff5555'
            // },
            smooth: true
          }
        ]
      })
    },
    pie (pieData) {
      const myChart = echarts.init(document.getElementById('pie'))
      myChart.setOption({
        tooltip: {
          trigger: 'item',
          formatter: '{a}<br/>{b}: {d}%' // 比例
          // formatter: '{a}-{b}-{c}' // 数量
        },
        legend: {
          orient: 'vertical',
          left: 'left'
        },
        toolbox: {
          show: true,
          feature: {
            dataView: { readOnly: false },
            magicType: { type: ['line', 'bar'] },
            restore: {},
            saveAsImage: {}
          }
        },
        series: [
          {
            name: '各类模型比例',
            type: 'pie',
            radius: '50%',
            // data: pieData,
            data: [
              { value: 1048, name: '疾病轨迹模型' },
              { value: 735, name: '单模态模型' },
              { value: 580, name: '多模态模型' }
            ],
            emphasis: {
              itemStyle: {
                shadowBlur: 10,
                shadowOffsetX: 0,
                shadowColor: 'rgba(0, 0, 0, 0.5)'
              }
            }
          }
        ]
      })
    },
    goToRunManager () {
      window.location.href = '/runManager'
    },
    goToMsgManager () {
      window.location.href = '/message'
    },
    goToResManager () {
      window.location.href = '/result'
    }
  },
  // 过滤器：处理数据格式
  filters: {
    num (value) {
      if (value === '') return
      return value.toLocaleString()
    }
  }
}
</script>

<style lang="less" scoped>
.home{
  width: 1400px;
  height: 1000px;
  background: #fff;
}
.header{
  display: flex;
  padding-top: 50px;
  padding-right: 50px;
  padding-left: 50px;
  width: 1200px;
  text-align: center;
}
.content{
  display: flex;
  margin: 50px;
  width: 1200px;
  flex: 1;
  .chart{
    margin: 10px; /* 外边距 */
    padding: 20px; /* 内边距 */
  }
}

.home-footer{
  display: flex;
  padding-left: 80px;
  padding-right: 50px;
  width: 1200px;
  .box-card{
    width: 400px;
  }
  .box-card-fast{
    width: 420px;
  }
}

.item{
  flex: 1;
  height: 100px;
  padding: 10px;
  border-radius: 10px;
  margin-left: 20px;
  margin-right: 20px;
  font-weight: bold;
  position: relative;
  background-image: linear-gradient(#81c461, #81c461);
  .item-center {
    font-size: 22px;
    top: 40px;
    margin: 10px;
    color: #000;
  }
  .item-up {
    font-size: 15px;
    top: 10px;
    margin: 5px;
    color: #000;
  }
  .num {
    font-size: 22px;
    padding: 10px;
    margin: 10px;
  }
  .bottom {
    position: relative;
    padding: 5px 5px;
    bottom: 5px;
    right: 0;
    left: 0;
    color: #ee1;
    font-weight: normal;
    text-align: left;
  }
}

.item-bottom{
  flex: 1;
  height: 100px;
  padding: 10px;
  border-radius: 10px;
  margin-left: 15px;
  margin-right: 15px;
  font-weight: bold;
  position: relative;
  width: 300px;
  text-align: center;
  background-image: linear-gradient(#f8bd47ca, #f8bd47ca);
  .num {
    font-size: 22px;
    margin: 10px;
    color: #f11;
  }
  .span-pad{
    top: 25px;
  }
}

.item-fast{
  flex: 1;
  text-align: center;
  height: 100px;
  padding: 10px;
  top: 25px;
  border-radius: 10px;
  margin-left: 10px;
  margin-right: 10px;
  position: relative;
}
</style>
