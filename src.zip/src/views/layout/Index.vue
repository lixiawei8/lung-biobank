<template>
  <div class="layout">
    <!-- 左侧导航 -->
    <div class="menu">
      <MyMenu :isCollapse="isCollapse"></MyMenu>
    </div>
    <!-- 右侧内容 -->
    <div class="content" :class="{small:isCollapse}">
      <MyContent @changeShow="changeShow" :isCollapse="isCollapse"></MyContent>
    </div>
  </div>
</template>

<script>
import MyMenu from './menu/Index.vue'
import MyContent from './content/Index.vue'
export default {
    name: 'MyLayout',
    components: {
      MyMenu,
      MyContent
    },
    data () {
      return {
        isCollapse: false
      }
    },
    methods: {
      changeShow () {
        this.isCollapse = !this.isCollapse
      }
    }
}
</script>

<style lang="less" scoped>
.layout{
  display: flex;
  .menu{
    background: #0c64c1;
    position: fixed;
    left: 0;
    top: 0;
    bottom: 0;
  }
  .content{
    padding-left: 200px;
  }
  .small{
    padding-left: 64px;
  }
}
</style>
