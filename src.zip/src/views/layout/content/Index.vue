<template>
  <div>
    <!-- 顶部 -->
    <div class="header">
      <div class="open">
        <span v-if="!isCollapse" class="iconfont icon-right-indent" @click="changeMenu"></span>
        <span v-else class="iconfont icon-left-indent" @click="changeMenu"></span>
      </div>
    </div>
    <!-- 内容 -->
     <div class="wrapper">
      <router-view></router-view>
     </div>

  </div>
</template>

<script>
export default {
  name: 'MyContent',
  props: ['isCollapse'],
  methods: {
    changeMenu () {
      this.$emit('changeShow')
    }
  }
}
</script>

<style lang="less" scoped>
.header{
  display: flex;
  height: 50px;
  line-height: 50px;
  .open{
    .iconfont{
      font-size: 22px;
      cursor: pointer;
      top: 0;
      background: #0c64c1;
    }
  }
}
.wrapper{
  padding: 20px;
}
</style>
