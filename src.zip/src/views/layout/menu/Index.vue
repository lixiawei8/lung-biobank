<template>
  <div>
    <el-menu class="el-menu-vertical-demo" default-active="/"
     background-color="#0c64c1" text-color="#fff" color="#ddd"
     active-text-color="#ffd04b" router :collapse="isCollapse">
      <el-menu-item>
        <span slot="title" class="title1">肺结节人工智能影像云平台</span>
      </el-menu-item>
      <el-menu-item>
        <div class="title-user"> 欢迎  {{ userInfo.uname }} </div>
      </el-menu-item>
      <el-menu-item index="/">
        <i class="el-icon-s-home"></i>
        <span slot="title">首页</span>
      </el-menu-item>
<el-submenu index="/clinical">
        <template slot="title">
          <i class="el-icon-s-grid"></i>
          <span>档案库</span>
        </template>
        <el-menu-item-group>
          <el-menu-item index="/clinical/list">
            <i class="el-icon-s-management"></i>
            <span slot="title">患者档案</span>
          </el-menu-item>
          <el-menu-item index="/clinical/list">
            <i class="el-icon-time"></i>
            <span slot="title">诊疗历史</span>
          </el-menu-item>
        </el-menu-item-group>
      </el-submenu>

      <el-submenu index="/clinical">
        <template slot="title">
          <i class="el-icon-s-flag"></i>
          <span>临床数据</span>
        </template>
        <el-menu-item-group>
          <el-menu-item index="/clinical/list">
            <i class="el-icon-star-on"></i>
            <span slot="title">数据列表</span>
          </el-menu-item>
          <el-menu-item index="/clinical/perf">
            <i class="el-icon-s-data"></i>
            <span slot="title">性能图</span>
          </el-menu-item>
          <el-menu-item index="/clinical/visual">
            <i class="el-icon-picture"></i>
            <span slot="title">可视化</span>
          </el-menu-item>
        </el-menu-item-group>
      </el-submenu>
      <el-submenu index="/imaging">
        <template slot="title">
          <i class="el-icon-s-flag"></i>
          <span>影像数据</span>
        </template>
        <el-menu-item-group>
          <el-menu-item index="/imaging/list">
            <i class="el-icon-star-on"></i>
            <span slot="title">数据列表</span>
          </el-menu-item>
          <el-menu-item index="/imaging/perf">
            <i class="el-icon-s-data"></i>
            <span slot="title">性能图</span>
          </el-menu-item>
          <el-menu-item index="/imaging/visual">
            <i class="el-icon-picture"></i>
            <span slot="title">可视化</span>
          </el-menu-item>
        </el-menu-item-group>
      </el-submenu>
      <el-submenu index="/gene">
        <template slot="title">
          <i class="el-icon-s-flag"></i>
          <span>基因数据</span>
        </template>
        <el-menu-item-group>
          <el-menu-item index="/gene/list">
            <i class="el-icon-star-on"></i>
            <span slot="title">数据列表</span>
          </el-menu-item>
          <el-menu-item index="/gene/perf">
            <i class="el-icon-s-data"></i>
            <span slot="title">性能图</span>
          </el-menu-item>
          <el-menu-item index="/gene/visual">
            <i class="el-icon-picture"></i>
            <span slot="title">可视化</span>
          </el-menu-item>
        </el-menu-item-group>
      </el-submenu>
      <el-submenu index="/pathology">
        <template slot="title">
          <i class="el-icon-s-flag"></i>
          <span>病理数据</span>
        </template>
        <el-menu-item-group>
          <el-menu-item index="/pathology/list">
            <i class="el-icon-star-on"></i>
            <span slot="title">数据列表</span>
          </el-menu-item>
          <el-menu-item index="/pathology/perf">
            <i class="el-icon-s-data"></i>
            <span slot="title">性能图</span>
          </el-menu-item>
          <el-menu-item index="/pathology/visual">
            <i class="el-icon-picture"></i>
            <span slot="title">可视化</span>
          </el-menu-item>
        </el-menu-item-group>
      </el-submenu>
      <el-submenu index="/system">
        <template slot="title">
          <i class="el-icon-s-tools"></i>
          <span>设置</span>
        </template>
        <el-menu-item-group>
          <el-menu-item index="/changePwd">
            <i class="el-icon-edit-outline"></i>
            <span slot="title">修改密码</span>
          </el-menu-item>
        </el-menu-item-group>
      </el-submenu>
      <el-submenu index="/exit">
        <template slot="title">
          <i class="el-icon-switch-button"></i>
          <span slot="title" @click="logout">退出</span>
        </template>
      </el-submenu>
      <el-menu-item>
        <div class="title2">{{ time }}</div>
      </el-menu-item>
    </el-menu>
  </div>
</template>

<script>
import dayjs from 'dayjs'
import { mapState } from 'vuex'
export default {
  props: ['isCollapse'],
  name: 'MyMenu',
  data () {
    return {
      time: ''
    }
  },
  created () {
    this.time = dayjs().format('YYYY/MM/DD HH:mm:ss')
    console.log('----------------------- this.userInfo id', this.userInfo.id)
    console.log('----------------------- this.userInfo uname', this.userInfo.uname)
  },
  // 取数据使用计算属性
  computed: {
    ...mapState('login', ['userInfo'])
  },
  methods: {
    logout () {
      localStorage.removeItem('info') // 删除store/index中所有信息
      // 进入登录界面
      this.$router.push('/login')
    }
  }
}
</script>

<style lang="less" scope>
.el-menu{
  border-right: 0;
  .title1{
    border: 0px;
    padding: 0px;
    margin: 0px;
    font-size: 20px;
  }
  .title-user{
    border: 0px;
    padding: 0px;
    margin: 0px;
    font-size: 13px;
    text-align: center !important;
  }

  .title2{
    border: 0px;
    padding: 0px;
    margin: 0px;
    font-size: 13px;
    text-align: center !important;
  }
}
.el-menu-vertical-demo:not(.el-menu--collapse) {
  width: 280px;
  min-height: 400px;
}
</style>
