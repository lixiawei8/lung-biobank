<template>
  <div class="wrapper">
    <div class="tab">
      <div class="my-title">影像模型的性能表现</div>
      <el-tabs stretch>
        <el-tab-pane label="对比实验">
          <div class="chart">
            <div>各模型在不同数据集上的预测结果（单位为%）</div>
            <div class="div-lines" id="lines"></div>
          </div>
        </el-tab-pane>
        <el-tab-pane label="模型大小">
          <div class="chart">
            <div>不同模型的大小</div>
            <div class="div-lines2" id="lines2"></div>
          </div>
        </el-tab-pane>
        <el-tab-pane label="消融分析">
          <div class="chart">
            <div>各模块对预测结果的影响（单位为%）</div>
            <div class="div-lines3" id="lines3"></div>
          </div>
        </el-tab-pane>
        <el-tab-pane label="融合方式实验">
          <div class="chart">
            <div>不同融合方式对预测结果的影响（单位为%）</div>
            <div class="div-lines3" id="lines4"></div>
          </div>
        </el-tab-pane>
        <el-tab-pane label="损失函数实验">
          <div class="chart">
            <div>不同损失函数对预测结果的影响（单位为%）</div>
            <div class="div-lines3" id="lines5"></div>
          </div>
        </el-tab-pane>
        <el-tab-pane label="模型评估（一）">
          <div class="chart">
            <div>不同模型和损失函数在各数据集上的 AUROC（单位为%）</div>
            <div class="div-lines3" id="lines6"></div>
          </div>
        </el-tab-pane>
        <el-tab-pane label="模型评估（二）">
          <div class="chart">
            <div>不同模型和损失函数在各数据集上的 AUPRC（单位为%）</div>
            <div class="div-lines3" id="lines7"></div>
          </div>
        </el-tab-pane>
      </el-tabs>
    </div>
  </div>
</template>

<script>
import * as echarts from 'echarts'
export default {
  name: 'MyDataImagingPerf',
  data () {
    return {
      // 临床数据表
      clinical: {
        tooltip: {
          trigger: 'axis'
        },
        legend: {
          orient: 'vertical',
          left: 'left'
        },
        toolbox: {
          show: true,
          feature: {
            dataView: { readOnly: true },
            magicType: { type: ['line', 'bar'] },
            restore: {},
            saveAsImage: {}
          }
        },
        grid: {
          left: '5%',
          right: '8%',
          bottom: '3%',
          top: '35%',
          containLabel: true
        },
        xAxis: {
          type: 'category',
          boundaryGap: false,
          data: ['CBCL-M_Rank1', 'CBCL-M_Rank5', 'LFW-M_Rank1', 'LFW-M_Rank5', 'LFW-M_mAP']
        },
        yAxis: {
          type: 'value'
        },
        series: [
          // CenterLoss 27.75 41.77 12.58 31.00 24.06
          {
            name: 'CenterLoss',
            type: 'line',
            data: [27.75, 41.77, 12.58, 31.00, 24.06]
          },
          // CosFace 41.85, 62.62, 13.33, 31.83, 24.88
          {
            name: 'CosFace',
            type: 'line',
            data: [41.85, 62.62, 13.33, 31.83, 24.88]
          },
          // ArcFace 44.15, 66.54, 15.33, 36.00, 27.60
          {
            name: 'ArcFace',
            type: 'line',
            data: [44.15, 66.54, 15.33, 36.00, 27.60]
          },
          // GroupFace 49.15, 73.68, 13.08, 32.58, 24.66
          {
            name: 'GroupFace',
            type: 'line',
            data: [49.15, 73.68, 13.08, 32.58, 24.66]
          },
          // CircleLoss 34.70, 59.98, 11.33, 28.67, 22.61
          {
            name: 'CircleLoss',
            type: 'line',
            data: [34.70, 59.98, 11.33, 28.67, 22.61]
          },
          // LPD 52.55, 78.92, 10.50, 26.25, 19.67
          {
            name: 'LPD',
            type: 'line',
            data: [52.55, 78.92, 10.50, 26.25, 19.67]
          },
          // FFR-Net 45.40, 69.01, 10.75, 28.42, 21.98
          {
            name: 'FFR-Net',
            type: 'line',
            data: [45.40, 69.01, 10.75, 28.42, 21.98]
          },
          // Bi-Att-Face 52.80, 79.08, 15.50, 41.08, 29.31
          {
            name: 'Bi-Att-Face',
            type: 'line',
            data: [52.80, 79.08, 15.50, 41.08, 29.31]
          }
        ]
      },

      // 模型大小表
      modelSize: {
        tooltip: {
          trigger: 'axis'
        },
        legend: {
        },
        toolbox: {
          show: true,
          feature: {
            dataView: { readOnly: true },
            magicType: { type: ['line', 'bar'] },
            restore: {},
            saveAsImage: {}
          }
        },
        grid: {
          bottom: '3%',
          top: '25%',
          containLabel: true
        },
        xAxis: {
          type: 'category',
          boundaryGap: false,
          data: ['CenterLoss', 'CosFace', 'ArcFace', 'GroupFace', 'CircleLoss', 'LPD', 'FFR-Net', 'Bi-Att-Face']
        },
        yAxis: {
          type: 'value'
        },
        series: [
          // Size(M) 82 82 82 88 82 95 224 138
          {
            name: 'ModelSize',
            type: 'line',
            data: [82, 82, 82, 88, 82, 95, 224, 138]
          }
        ]
      },

      // ablation辨识准确度
      ablation: {
        tooltip: {
          trigger: 'axis'
        },
        legend: {
          orient: 'vertical',
          left: 'left'
        },
        toolbox: {
          show: true,
          feature: {
            dataView: { readOnly: true },
            magicType: { type: ['line', 'bar'] },
            restore: {},
            saveAsImage: {}
          }
        },
        grid: {
          bottom: '3%',
          top: '25%',
          containLabel: true
        },
        xAxis: {
          type: 'category',
          boundaryGap: false,
          data: ['CBCL-M_Rank1', 'CBCL-M_Rank5', 'LFW-M_Rank1', 'LFW-M_Rank5']
        },
        yAxis: {
          type: 'value'
        },
        series: [
          // Bi-Att-Face w/o satt 38.42 69.09 13.02 39.22
          {
            name: 'Bi-Att-Face w/o satt',
            type: 'line',
            data: [38.42, 69.09, 13.02, 39.22]
          },
          // Bi-Att-Face w/o satt 47.20 77.26 14.79 40.89
          {
            name: 'Bi-Att-Face w/o catt',
            type: 'line',
            data: [47.20, 77.26, 14.79, 40.89]
          },
          // Bi-Att-Face 52.80 79.08 15.50 41.08
          {
            name: 'Bi-Att-Face',
            type: 'line',
            data: [52.80, 79.08, 15.50, 41.08]
          }
        ]
      },

      // 融合方式实验表
      fushion: {
        tooltip: {
          trigger: 'axis'
        },
        legend: {
          orient: 'vertical',
          left: 'left'
        },
        toolbox: {
          show: true,
          feature: {
            dataView: { readOnly: true },
            magicType: { type: ['line', 'bar'] },
            restore: {},
            saveAsImage: {}
          }
        },
        grid: {
          bottom: '3%',
          top: '25%',
          containLabel: true
        },
        xAxis: {
          type: 'category',
          boundaryGap: false,
          data: ['CBCL-M_Rank1', 'CBCL-M_Rank5', 'LFW-M_Rank1', 'LFW-M_Rank5']
        },
        yAxis: {
          type: 'value'
        },
        series: [
          // Bi-Att-Face add 40.29 76.04 14.64 40.40
          {
            name: 'Bi-Att-Face add',
            type: 'line',
            data: [40.29, 76.04, 14.64, 40.40]
          },
          // Bi-Att-Face cat 43.68 74.39 13.95 39.27
          {
            name: 'Bi-Att-Face cat',
            type: 'line',
            data: [43.68, 74.39, 13.95, 39.27]
          },
          // Bi-Att-Face mul 52.80 79.08 15.50 41.08
          {
            name: 'Bi-Att-Face mul',
            type: 'line',
            data: [52.80, 79.08, 15.50, 41.08]
          }
        ]
      },

      // 损失函数实验表
      lossFunc: {
        tooltip: {
          trigger: 'axis'
        },
        legend: {
          orient: 'vertical',
          left: 'left'
        },
        toolbox: {
          show: true,
          feature: {
            dataView: { readOnly: true },
            magicType: { type: ['line', 'bar'] },
            restore: {},
            saveAsImage: {}
          }
        },
        grid: {
          bottom: '3%',
          top: '25%',
          containLabel: true
        },
        xAxis: {
          type: 'category',
          boundaryGap: false,
          data: ['CBCL-M_Rank1', 'CBCL-M_Rank5', 'LFW-M_Rank1', 'LFW-M_Rank5', 'LFW-M_mAP']
        },
        yAxis: {
          type: 'value'
        },
        series: [
          // Bi-Att-Face tri 44.80 67.08 11.92 31.00 23.11
          {
            name: 'Bi-Att-Face tri',
            type: 'line',
            data: [44.80, 67.08, 11.92, 31.00, 23.11]
          },
          // Bi-Att-Face quad 52.80 79.08 15.50 41.08 29.31
          {
            name: 'Bi-Att-Face quad',
            type: 'line',
            data: [52.80, 79.08, 15.50, 41.08, 29.31]
          }
        ]
      },

      // 人脸验证评估表1
      validation1: {
        tooltip: {
          trigger: 'axis'
        },
        legend: {
          orient: 'vertical',
          left: 'left'
        },
        toolbox: {
          show: true,
          feature: {
            dataView: { readOnly: true },
            magicType: { type: ['line', 'bar'] },
            restore: {},
            saveAsImage: {}
          }
        },
        grid: {
          bottom: '3%',
          top: '30%',
          containLabel: true
        },
        xAxis: {
          type: 'category',
          boundaryGap: false,
          data: ['AgeDB-30-M', 'CALFW-M', 'CFP-FF-M', 'CFP-FP-M', 'CPLFW-MP']
        },
        yAxis: {
          type: 'value'
        },
        series: [
          // LPD 8.97 11.90 17.80 8.94 10.47
          {
            name: 'LPD',
            type: 'line',
            data: [8.97, 11.90, 17.80, 8.94, 10.47]
          },
          // FFR-Net 9.43 11.07 15.77 10.83 11.07
          {
            name: 'FFR-Net',
            type: 'line',
            data: [9.43, 11.07, 15.77, 10.83, 11.07]
          },
          // Bi-Att-Face tri 9.43 12.60 23.17 10.69 9.33
          {
            name: 'Bi-Att-Face tri',
            type: 'line',
            data: [9.43, 12.60, 23.17, 10.69, 9.33]
          },
          // Bi-Att-Face quad 11.67 19.70 29.23 9.29 11.67
          {
            name: 'Bi-Att-Face quad',
            type: 'line',
            data: [11.67, 19.70, 29.23, 9.29, 11.67]
          }
        ]
      },

      // 人脸验证评估表2
      validation2: {
        tooltip: {
          trigger: 'axis'
        },
        legend: {
          orient: 'vertical',
          left: 'left'
        },
        toolbox: {
          show: true,
          feature: {
            dataView: { readOnly: true },
            magicType: { type: ['line', 'bar'] },
            restore: {},
            saveAsImage: {}
          }
        },
        grid: {
          bottom: '3%',
          top: '30%',
          containLabel: true
        },
        xAxis: {
          type: 'category',
          boundaryGap: false,
          data: ['AgeDB-30-M', 'CALFW-M', 'CFP-FF-M', 'CFP-FP-M', 'CPLFW-MP']
        },
        yAxis: {
          type: 'value'
        },
        series: [
          // LPD 17.73, 19.20, 27.49, 16.91, 18.00
          // FFR-Net 14.97, 20.60, 26.20, 19.09, 17.70
          // Bi-Att-Face tri 16.73, 20.83, 36.60, 18.51, 16.50
          // Bi-Att-Face quad 20.67, 30.30, 42.69, 17.74, 19.70
          {
            name: 'LPD',
            type: 'line',
            data: [17.73, 19.20, 27.49, 16.91, 18.00]
          },
          {
            name: 'FFR-Net',
            type: 'line',
            data: [14.97, 20.60, 26.20, 19.09, 17.70]
          },
          {
            name: 'Bi-Att-Face tri',
            type: 'line',
            data: [16.73, 20.83, 36.60, 18.51, 16.50]
          },
          {
            name: 'Bi-Att-Face quad',
            type: 'line',
            data: [20.67, 30.30, 42.69, 17.74, 19.70]
          }
        ]
      }
    }
  },
  mounted () {
    // 7个表
    this.lines()
    this.lines2()
    this.lines3()
    this.lines4()
    this.lines5()
    this.lines6()
    this.lines7()
  },
  methods: {
    lines () {
      const chartDom = document.getElementById('lines')
      const myChart = echarts.init(chartDom)
      this.clinical && myChart.setOption(this.clinical)
    },
    lines2 () {
      const chartDom = document.getElementById('lines2')
      const myChart = echarts.init(chartDom)
      this.modelSize && myChart.setOption(this.modelSize)
    },
    lines3 () {
      const chartDom = document.getElementById('lines3')
      const myChart = echarts.init(chartDom)
      this.ablation && myChart.setOption(this.ablation)
    },
    lines4 () {
      const chartDom = document.getElementById('lines4')
      const myChart = echarts.init(chartDom)
      this.fushion && myChart.setOption(this.fushion)
    },
    lines5 () {
      const chartDom = document.getElementById('lines5')
      const myChart = echarts.init(chartDom)
      this.lossFunc && myChart.setOption(this.lossFunc)
    },
    lines6 () {
      const chartDom = document.getElementById('lines6')
      const myChart = echarts.init(chartDom)
      this.validation1 && myChart.setOption(this.validation1)
    },
    lines7 () {
      const chartDom = document.getElementById('lines7')
      const myChart = echarts.init(chartDom)
      this.validation2 && myChart.setOption(this.validation2)
    }
  }
}
</script>

<style lang="less" scoped>
.wrapper{
  height: 1000px;
  width: 1300px;
  background: #fff;
  margin: 0px;
  margin-left: 80px;
  border: 0px;
  padding: 0px;
  .el-tabs{
    margin: 30px;
    padding: 20px;
    .chart{
      > div{
        text-align: center !important;
        font-size: 18px;
        margin-top: 30px;
      }
    }
  }
}
.tab{
  padding: 20px;
}
.my-title{
  background: #eee;
  margin: 0px;
  border: 0px;
  padding: 10px;
  color: #333;
  font-weight: bold;
}
.div-lines{
  width: 800px;
  height: 700px;
  padding: 10px;
  background: ivory;
  margin-top: 50px;
  margin-left: 160px;
}
.div-lines2{
  width: 850px;
  height: 430px;
  padding: 10px;
  background: ivory;
  margin-top: 50px;
  margin-left: 120px;
}
.div-lines3{
  width: 700px;
  height: 500px;
  padding: 10px;
  background: ivory;
  margin-top: 50px;
  margin-left: 160px;
}
</style>
