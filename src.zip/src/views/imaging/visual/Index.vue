<template>
  <div class="wrapper">
    <div class="image">
      <div class="my-title">影像模型可视化</div>
      <div class="demo">
        <div class="title">模型在不同数据集上**权重的可视化结果</div>
        <el-image style="width: 1150px; height: 400px" :src="impath" :fit="fit"></el-image>
        <div>(a) 数据集 A 上的部分可视化结果
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          &nbsp;&nbsp;&nbsp;&nbsp;
          (b) 数据集 B 上的部分可视化结果</div>
      </div>
    </div>
  </div>
</template>

<script>
import { host } from '@/api/base'
export default {
  name: 'MyDataImagingVisual',
  data () {
    return {
      fit: 'fill',
      impath: host + '/' + 'visual/ch3.png'
    }
  },
  mounted () {
    console.log('---------------img url', this.impath)
  },
  methods: {

  }
}
</script>

<style lang="less" scoped>
.wrapper{
  height: 950px;
  width: 1300px;
  margin: 0px;
  margin-left: 80px;
  border: 0px;
  padding: 0px;
  background: #fff;
  .demo{
    .title{
      font-size: 22px;
    }
    > div {
      text-align: center !important;
      font-size: 18px;
      font-family: '楷体', 'Times New Roman';
    }
    .el-image{
      margin-top: 80px;
      margin-bottom: 5px;
    }
    margin: 50px;
    padding-top: 60px;
    text-align: center;
  }
}
.image{
  padding: 20px;
  background: #fff;
}
.my-title{
  background: #eee;
  margin: 0px;
  border: 0px;
  padding: 10px;
  color: #333;
  font-weight: bold;
}
</style>
