<template>
  <div class="wrapper">
    <div class="form">
      <div class="my-title">详情</div>
      <br/>
      <el-form label-position="left" :model="ruleForm" label-width="100px" class="elForm">
        <el-form-item label="患者编号">
          <span>{{ ruleForm.id }}</span>
        </el-form-item>
        <el-form-item label="数据名称">
          <span>{{ ruleForm.name }}</span>
        </el-form-item>
        <el-form-item label="数据类别">
          <span>{{ ruleForm.category }}</span>
        </el-form-item>
        <el-form-item label="添加时间">
          <span>{{ dayjs(ruleForm.createTime).format('YYYY-MM-DD HH:mm:ss') }}</span>
        </el-form-item>
        <!-- <el-form-item label="数据特点">
          <span>{{ ruleForm.feature }}</span>
        </el-form-item> -->
        <el-form-item label="数据描述">
          <span>{{ removeHTMLTag(ruleForm.description) }}</span>
        </el-form-item>
        <el-form-item label="样例语句">
          <span>{{ ruleForm.codeStr }}</span>
        </el-form-item>
<!--  -->
        <el-form-item label="源码列表">
          <span>{{ ruleForm.scriptPath }}</span>
        </el-form-item>

        <el-form-item label="数据文件">
          <span>{{ ruleForm.modelPath }}</span>
        </el-form-item>
        <el-form-item label="任务类别">
          <el-select v-model="ruleForm.task" placeholder="请选择任务">
            <el-option label="单任务人脸识别" value="singleRecognition"></el-option>
            <el-option label="图像集人脸识别" value="imagesRecognition"></el-option>
            <el-option label="批量任务人脸识别" value="batchRecognition"></el-option>
            <el-option label="批量任务人脸验证" value="batchValidation"></el-option>
          </el-select>
        </el-form-item>

        <!-- 单任务识别 -->
        <el-form-item v-if="ruleForm.task==='singleRecognition'" label="待识别图像">
          <el-form-item prop="probeImage">
            <UploadImg @sendImg="sendImage"></UploadImg>
          </el-form-item>
        </el-form-item>

        <!-- 批量任务识别 -->
        <el-form-item v-if="ruleForm.task==='batchRecognition'" label="待识别数据集">
          <el-select v-model="recognitionDB" placeholder="请选择数据集">
            <el-option label="CBCL-M" value="CBCL-M"></el-option>
            <el-option label="LFW-M" value="LFW-M"></el-option>
          </el-select>
        </el-form-item>

        <!-- 批量任务验证 -->
        <el-form-item v-if="ruleForm.task==='batchValidation'" label="待验证数据集">
          <el-select v-model="validationDB" placeholder="请选择数据集">
            <el-option label="agedb-30" value="agedb-30"></el-option>
            <el-option label="calfw" value="calfw"></el-option>
            <el-option label="cfp-ff" value="cfp-ff"></el-option>
            <el-option label="cfp-fp" value="cfp-fp"></el-option>
            <el-option label="cplfw" value="cplfw"></el-option>
          </el-select>
        </el-form-item>
      </el-form>
    </div>

    <div class="code">
      <h3 class="title2">主要代码</h3>
      <br>
      <el-card class="box-card">
        <div>
            <el-tabs stretch type="border-card" v-model="activeName">
            <el-tab-pane label="数据结构" name="first">
              <pre><code>{{modelStr}}</code></pre>
            </el-tab-pane>
            <el-tab-pane label="注意力机制" name="second">
              <pre><code>{{attentionStr}}</code></pre>
            </el-tab-pane>
            <el-tab-pane label="数据加载器" name="third">
              <pre><code>{{loaderStr}}</code></pre>
            </el-tab-pane>
            <el-tab-pane label="损失函数" name="fourth">
              <pre><code>{{lossStr}}</code></pre>
            </el-tab-pane>
            <el-tab-pane label="通用工具" name="fifth">
              <pre><code>{{utilStr}}</code></pre>
            </el-tab-pane>
            <el-tab-pane label="度量方法" name="sixth">
              <pre><code>{{metricStr}}</code></pre>
            </el-tab-pane>
            <el-tab-pane label="配置文件" name="seventh">
              <pre><code>{{configStr}}</code></pre>
            </el-tab-pane>
            <el-tab-pane label="测试文件" name="eighth">
              <pre><code>{{mainStr}}</code></pre>
            </el-tab-pane>
          </el-tabs>
        </div>
      </el-card>
    </div>

    <div class="resForm">
      <h3 class="title2">运行输出</h3>
      <br>
      <el-form>
        <el-form-item>
          <textarea size="big" v-model="codeResult" class="txtArea"></textarea>
        </el-form-item>
      </el-form>
    </div>

    <div class="run-btn">
      <el-button size="big" type="success" plain @click="runLine">运行样例语句</el-button>
      <el-button size="big" type="success" @click="runScript">执行测试文件</el-button>
      <el-button size="big" @click="closePage">关闭</el-button>
    </div>

    <div v-if="ruleForm.task==='singleRecognition'" class="resImage">
      <div>
        <br/>
        <div>待测图像
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;预测结果</div>
        <br/>
        <el-image style="width: 150px; height: 150px" :src="probeImagePath"></el-image>
        &nbsp;
        <el-image style="width: 150px; height: 150px" :src="predictedImagePath"></el-image>
      </div>
    </div>
  </div>
</template>

<script>
import { mapState } from 'vuex'
import { host } from '@/api/base'
import dayjs from 'dayjs'
import { removeHTMLTag } from '@/utils/common.js' // 对象格式
import UploadImg from '@/components/UploadImg.vue'
export default {
  name: 'MyImagingDetail',
  components: {
    UploadImg
  },
  data () {
    return {
      modelStr: '',
      attentionStr: '',
      loaderStr: '',
      lossStr: '',
      utilStr: '',
      metricStr: '',
      configStr: '',
      mainStr: '',

      codeFileList: [], // code文件path集
      modelFileList: [], // model文件集合
      activeName: 'eighth', // 默认选中7th卡
      mainFPath: '',

      imagePath: '', // image file
      recognitionDB: '',
      validationDB: '',

      codeResult: null, // res for code
      ruleForm: {
        id: '',
        name: '',
        category: '',
        feature: '',
        description: '',
        codeStr: '',
        scriptPath: [],
        modelPath: [],
        task: ''
      },
      // 文件执行后返回的图像
      probeImagePath: '',
      predictedImagePath: ''
    }
  },
  created () {
  },
  methods: {
    dayjs,
    // 清除html标记
    removeHTMLTag,

    // 接收上传图像文件path
    sendImage (fname) {
      this.imagePath = 'upload/' + fname
      this.probeImagePath = host + this.imagePath.split('upload')[1]
    },

    // 数据运行--执行python语句
    async runLine () {
      this.codeResult = null
      try {
        const pythonCode = this.ruleForm.codeStr
        const response = await this.$api.execCode({ codeStr: pythonCode })
        this.codeResult = response.data.result
      } catch (err) {
        this.codeResult = '运行python语句失败'
      }
    },

    // 数据运行--执行python文件（测试入口文件）
    async runScript () {
      const time1 = (new Date()).getTime() / 1000 // s
      console.log('----------------- 目前的时间(s): ', time1)

      let thirdParam = '0'
      if (this.ruleForm.task === 'singleRecognition') {
        thirdParam = this.imagePath
      } else if (this.ruleForm.task === 'batchRecognition') {
        thirdParam = this.recognitionDB
      } else if (this.ruleForm.task === 'batchValidation') {
        thirdParam = this.validationDB
      }

      console.log('--------------thirdParam', thirdParam)
      const modelFPath = 'upload/' + JSON.parse(this.newData.modelPath)[0] // 默认取第一个模型
      this.codeResult = null
      try {
        const response = await this.$api.execScript({
          pythonFPath: this.mainFPath,
          modelFPath: modelFPath,
          task: this.ruleForm.task,
          thirdParam: thirdParam
        })

        if (this.ruleForm.task === 'singleRecognition') {
          // 图像单任务识别
          this.codeResult = response.data.result
          const resArr = this.codeResult.split('\n')
          let recognitionResult
          resArr.forEach(e => {
            if (e.indexOf('predicted image: ') !== -1) {
              this.predictedImagePath = e.split('predicted image:')[1]
            } else if (e.indexOf('预测') !== -1) {
              recognitionResult = e.split('预测')[1]
            }
          })

          this.predictedImagePath = host + this.predictedImagePath.split('upload')[1]
          this.$alert('识别' + recognitionResult, '图像识别结果', {
            confirmButtonText: '确定'
          })
        } else if (this.ruleForm.task === 'imagesRecognition') {
          // 图像集识别
          this.codeResult = response.data.result

          let imagesAccuracy
          const resArr = this.codeResult.split('\n')
          resArr.forEach(e => {
            if (e.indexOf('Accuracy: ') !== -1) {
              imagesAccuracy = e.split('Accuracy: ')[1]
            }
          })
          this.$alert('准确度: ' + (100 * (imagesAccuracy)).toFixed(2) + '%', '图像集识别结果', {
            confirmButtonText: '确定'
          })
        } else if (this.ruleForm.task === 'batchRecognition') {
          // 批量识别
          this.codeResult = response.data.result
          // console.log('----------------- codeResult: ', this.codeResult)

          let Rank1, Rank5
          const resArr = this.codeResult.split('\n')
          resArr.forEach(e => {
            if (e.indexOf('Rank1: ') !== -1) {
              Rank1 = e.split('Rank1: ')[1]
            } else if (e.indexOf('Rank5: ') !== -1) {
              Rank5 = e.split('Rank5: ')[1]
            }
          })

          const res = 'Rank1: ' + (100 * (Rank1)).toFixed(2) + '%, ' + 'Rank5: ' + (100 * (Rank5)).toFixed(2) + '%'
          this.$alert(res, '批量任务识别结果', {
            confirmButtonText: '确定'
          })
        } else if (this.ruleForm.task === 'batchValidation') {
          // 批量验证
          this.codeResult = response.data.result
          console.log('----------------- codeResult: ', this.codeResult)

          let TAR_FAR_0, TAR_FAR_1 // TAR@FAR=5e-2 TAR@FAR=1e-1
          const resArr = this.codeResult.split('\n')
          resArr.forEach(e => {
            if (e.indexOf('TAR@FAR=5e-2: ') !== -1) {
              TAR_FAR_0 = e.split('TAR@FAR=5e-2: ')[1]
            } else if (e.indexOf('TAR@FAR=1e-1: ') !== -1) {
              TAR_FAR_1 = e.split('TAR@FAR=1e-1: ')[1]
            }
          })

          const res = 'TAR@FAR=5e-2: ' + (100 * (TAR_FAR_0)).toFixed(2) + '%,  ' + 'TAR@FAR=1e-1: ' + (100 * (TAR_FAR_1)).toFixed(2) + '%'
          this.$alert(res, '批量任务验证结果', {
            confirmButtonText: '确定'
          })
        }
      } catch (err) {
        this.codeResult = '运行python文件失败'
      }
      const time2 = (new Date()).getTime() / 1000 // s
      console.log('----------------- 目前的时间(s): ', time2, ', 使用时间(s): ', time2 - time1)
    },

    // 显示文件内容
    async runReader () { // mounted时执行
      const codeArr = JSON.parse(this.newData.scriptPath)
      let modelFPath = ''
      let attentionFPath = ''
      let loaderFPath = ''
      let lossFPath = ''
      let utilFPath = ''
      let metricFPath = ''
      let configFPath = ''
      let mainFPath = ''

      codeArr.forEach(e => {
        const fname = e.indexOf('/') !== -1 ? e.split('/')[1] : e
        const url = host + '/' + e
        if (fname.indexOf('model') !== -1) {
          modelFPath = url
        } else if (fname.indexOf('attention') !== -1) {
          attentionFPath = url
        } else if (fname.indexOf('loader') !== -1) {
          loaderFPath = url
        } else if (fname.indexOf('loss') !== -1) {
          lossFPath = url
        } else if (fname.indexOf('util') !== -1) {
          utilFPath = url
        } else if (fname.indexOf('metric') !== -1) {
          metricFPath = url
        } else if (fname.indexOf('config') !== -1) {
          configFPath = url
        } else if (fname.indexOf('main') !== -1) {
          mainFPath = url
        }
      })

      // 模型结构
      this.modelStr = ''
      try {
        const relativePath = 'upload/' + modelFPath.split(host + '/')[1]
        const response = await this.$api.readFile({ fpath: relativePath })
        this.modelStr = response.data.result
      } catch (err) {
        this.modelStr = 'read' + modelFPath + '文件失败'
      }

      // 注意力文件
      this.attentionStr = ''
      try {
        const relativePath = 'upload/' + attentionFPath.split(host + '/')[1]
        const response = await this.$api.readFile({ fpath: relativePath })
        this.attentionStr = response.data.result
      } catch (err) {
        this.attentionStr = 'read' + attentionFPath + '文件失败'
      }

      // 数据加载器文件
      this.loaderStr = ''
      try {
        const relativePath = 'upload/' + loaderFPath.split(host + '/')[1]
        const response = await this.$api.readFile({ fpath: relativePath })
        this.loaderStr = response.data.result
      } catch (err) {
        this.loaderStr = 'read' + loaderFPath + '文件失败'
      }

      // loss文件
      this.lossStr = ''
      try {
        const relativePath = 'upload/' + lossFPath.split(host + '/')[1]
        const response = await this.$api.readFile({ fpath: relativePath })
        this.lossStr = response.data.result
      } catch (err) {
        this.lossStr = 'read' + lossFPath + '文件失败'
      }

      // 通用工具
      this.utilStr = ''
      try {
        const relativePath = 'upload/' + utilFPath.split(host + '/')[1]
        const response = await this.$api.readFile({ fpath: relativePath })
        this.utilStr = response.data.result
      } catch (err) {
        this.utilStr = 'read' + utilFPath + '文件失败'
      }

      // 度量方法
      this.metricStr = ''
      try {
        const relativePath = 'upload/' + metricFPath.split(host + '/')[1]
        const response = await this.$api.readFile({ fpath: relativePath })
        this.metricStr = response.data.result
      } catch (err) {
        this.metricStr = 'read' + metricFPath + '文件失败'
      }

      // config文件
      this.configStr = ''
      try {
        const relativePath = 'upload/' + configFPath.split(host + '/')[1]
        const response = await this.$api.readFile({ fpath: relativePath })
        this.configStr = response.data.result
      } catch (err) {
        this.configStr = 'read' + configFPath + '文件失败'
      }

      // 测试文件
      this.mainStr = ''
      try {
        this.mainFPath = 'upload/' + mainFPath.split(host + '/')[1]
        const response = await this.$api.readFile({ fpath: this.mainFPath })
        this.mainStr = response.data.result
      } catch (err) {
        this.mainStr = 'read' + mainFPath + '文件失败'
      }
    },

    // 关闭页面
    closePage () {
      this.$router.push('/imaging/list')
    }
  },
  mounted () {
    // Prism.highlightAll()

    this.rowData = JSON.parse(JSON.stringify(this.newData)) // deep copy
    this.ruleForm = this.rowData
    this.ruleForm.isShow = true

    // 回显code file
    this.codeFileList = []
    const codeFiles = this.rowData.scriptPath
    const codeArr = JSON.parse(codeFiles)
    codeArr.forEach(e => {
      let name = e.indexOf('-') !== -1 ? e.split('-')[1] : e
      name = name.indexOf('/') !== -1 ? name.split('/')[1] : name
      this.codeFileList.push(name)
    })
    this.ruleForm.scriptPath = this.codeFileList.join(', ')

    // 回显model file
    this.modelFileList = []
    const modelFiles = this.rowData.modelPath
    const modelArr = JSON.parse(modelFiles)
    modelArr.forEach(e => {
      let name = e.indexOf('-') !== -1 ? e.split('-')[1] : e
      name = name.indexOf('/') !== -1 ? name.split('/')[1] : name
      this.modelFileList.push(name)
    })
    this.ruleForm.modelPath = this.modelFileList.join(', ')

    // 显示各类代码
    this.runReader()
  },
  computed: {
    ...mapState('model', ['title', 'newData']) // 读取model模块
  }
}
</script>

<style lang="less" scoped>
.wrapper{
  width: 1300px;
  margin: 0px;
  margin-left: 45px;
  border: 0px;
  padding: 0px;

  .form{
    padding: 20px;
    background: #fff;
    .my-title{
      background: #eee;
      padding: 10px;
      color: #333;
      font-weight: bold;
    }
    .elForm{
      height: 860px;
      margin-top: 10px;
      margin-left: 20px;
      .el-form-item span{
        font-family: '楷体', 'Times New Roman';
        font-size: 15px;
      }
    }
  }
  .title2{
    padding-top: 50px;
    padding-left: 20px;
    font-weight: bold;
  }
  .code{
    width: 1400px;
    .language-python{
      margin: 0px;
      border: 0px;
      padding: 0px;
    }
  }
  .resForm{
    width: 1400px;
  }
  .run-btn{
    width: 1400px;
    margin-top: 0px;
    margin-bottom: 20px;
    text-align: center
  }
  .txtArea{
    height: 200px;
    font-size: 16px;
    width: 1400px;
    border: 0px;
  }
  .resImage{
    height: 240px;
    width: 1400px;
    padding-top: 20px;
    text-align: center;
    background: #fff;
  }
}
</style>
