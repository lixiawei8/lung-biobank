<template>
  <div class="wrapper">
    <div class="my-title">&nbsp;&nbsp; &nbsp;&nbsp;数据{{ title }}</div>
    <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
      <el-form-item label="数据名称" prop="name">
        <el-input v-model="ruleForm.name"></el-input>
      </el-form-item>
      <el-form-item label="数据类别" prop="category">
        <el-select v-model="ruleForm.category" placeholder="请选择数据类别">
          <el-option label="影像数据" value="imaging"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="数据特点" prop="feature">
        <el-input v-model="ruleForm.feature"></el-input>
      </el-form-item>
      <el-form-item label="数据描述" prop="description">
        <el-input type="textarea" v-model="ruleForm.description"></el-input>
      </el-form-item>
      <el-form-item label="样例语句" prop="code">
        <el-input type="textarea" v-model="ruleForm.code"></el-input>
      </el-form-item>
      <el-form-item label="源码文件" prop="codeFiles">
        <UploadFile @sendFile="sendFile" @removeFile="removeFile" ref="uploadCodeFiles" :fileList="codeFileList"></UploadFile>
      </el-form-item>
      <el-form-item label="数据文件" prop="modelFiles">
        <UploadFile @sendFile="sendModel" @removeFile="removeModel" ref="uploadModelFiles" :fileList="modelFileList"></UploadFile>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="submitForm('ruleForm')">保存</el-button>
        <el-button type="primary" plain @click="resetForm('ruleForm')">重置</el-button>
        <el-button @click="closePage">取消</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
import UploadFile from '@/components/UploadFile.vue'
import { mapState } from 'vuex'
import { host } from '@/api/base'

export default {
  name: 'MyImagingPage',
  components: {
    UploadFile
  },
  computed: {
    ...mapState('model', ['title', 'newData']) // 读取model模块
  },
  data () {
    return {
      codeFileList: [], // code文件集合
      modelFileList: [], // model文件集合

      ruleForm: {
        id: '',
        name: '',
        category: '',
        feature: '',
        description: '',
        code: '',
        scriptPath: [],
        modelPath: [],
        imagePath: []
      },
      rules: {
        name: [
          { required: true, message: '请输入数据名称', trigger: 'blur' },
          { min: 3, max: 30, message: '长度在 3 到 30 个字符', trigger: 'blur' }
        ],
        category: [
          { required: true, message: '请填写类别', trigger: 'blur' }
        ]
      }
    }
  },
  methods: {
    // sendFile均由组件发出，但具体方法由自己定义：file model ..
    // 接收上传源代码文件path
    sendFile (fname) { // 收到时执行
      console.log('----------sendFile file, [fname]', fname)
      this.ruleForm.scriptPath.push(fname)
    },
    // remove scriptPath
    removeFile (val) {
      const index = this.ruleForm.scriptPath.indexOf(val)
      this.ruleForm.scriptPath.splice(index, 1)
    },

    // 接收上传数据文件 path
    sendModel (fname) {
      console.log('----------sendFile file, [fname]', fname)
      this.ruleForm.modelPath.push(fname)
    },
    // remove model path
    removeModel (val) {
      const index = this.ruleForm.modelPath.indexOf(val)
      this.ruleForm.modelPath.splice(index, 1)
    },

    // 接收上传图片path
    sendImg (fname) {
      console.log('----------sendFile file, [fname]', fname)
      this.ruleForm.imagePath.push(fname)
    },
    // remove图片path
    removeImg (val) {
      const index = this.ruleForm.imagePath.indexOf(val)
      this.ruleForm.imagePath.splice(index, 1)
    },

    // 添加数据信息
    async insertItem (params) {
      const res = await this.$api.insertItem(params)
      console.log('------------添加数据res', res.data)
      if (res.data.status === 200) {
        this.$message({
          message: '数据信息添加成功！',
          type: 'success'
        })
        this.$router.push('/imaging/list')
      } else {
        this.$message({
          message: '数据信息添加失败！',
          type: 'error'
        })
      }
    },

    // 修改数据信息
    async updateItem (params) {
      const res = await this.$api.updateItem(params)
      console.log('------------修改数据res', res.data)
      if (res.data.status === 200) {
        this.$message({
          message: '数据信息修改成功！',
          type: 'success'
        })
        this.$router.push('/imaging/list')
      } else {
        this.$message({
          message: '数据信息修改失败！',
          type: 'error'
        })
      }
    },

    // 提交表单
    submitForm (formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          console.log('-------------------[this ruleForm]', this.ruleForm)
          let { id, name, category, feature, description, code, scriptPath, modelPath, imagePath } = this.ruleForm
          code = code.replaceAll('\'', '"')
          scriptPath = JSON.stringify(scriptPath)
          modelPath = JSON.stringify(modelPath)
          imagePath = JSON.stringify(imagePath)

          if (this.title === '添加') {
            console.log('-------------------添加数据信息', this.ruleForm)
            this.insertItem({ name, category, feature, description, code, scriptPath, modelPath, imagePath })
          } else {
            console.log('------------------修改数据信息', this.ruleForm)
            this.updateItem({ id, name, category, feature, description, code, scriptPath, modelPath, imagePath })
          }
        } else {
          console.log('error submit!')
          return false
        }
      })
    },

    // 重置表单
    resetForm (formName) { // 添加和编辑时不同
      if (this.title === '添加') {
        this.$refs[formName].resetFields()
        this.$refs.uploadCodeFiles.clear()
        this.$refs.uploadModelFiles.clear()
      } else { // 编辑
        // 恢复之前的默认值
        const rowData = JSON.parse(JSON.stringify(this.newData))
        this.ruleForm = rowData
        this.ruleForm.isShow = true

        // 回显code file
        this.codeFileList = []
        const codeFiles = rowData.scriptPath
        const codeArr = JSON.parse(codeFiles)
        this.ruleForm.scriptPath = codeArr
        codeArr.forEach(e => {
          let name = e.indexOf('-') !== -1 ? e.split('-')[1] : e
          name = name.indexOf('/') !== -1 ? name.split('/')[1] : name
          const url = host + '/' + e
          this.codeFileList.push({ name: name, url: url }) // name url固定字段
        })

        // 回显model file
        this.modelFileList = []
        const modelFiles = rowData.modelPath
        const modelArr = JSON.parse(modelFiles)
        this.ruleForm.modelPath = modelArr
        modelArr.forEach(e => {
          let name = e.indexOf('-') !== -1 ? e.split('-')[1] : e
          name = name.indexOf('/') !== -1 ? name.split('/')[1] : name
          const url = host + '/' + e
          this.modelFileList.push({ name: name, url: url })
        })
      }
    },

    // 关闭页面
    closePage () {
      this.$router.push('/imaging/list')
    }
  },
  mounted () {
    if (this.title === '编辑') {
      console.log('-----------------------edit, imaging page, this.newData', this.newData)
      // this.ruleForm = { ...this.newData } // 渲染数据, ...: obj浅拷贝
      this.ruleForm = JSON.parse(JSON.stringify(this.newData)) // or
      this.ruleForm.isShow = true
      console.log('-----------------------edit, this.ruleForm', this.ruleForm)

      // 回显code file
      this.codeFileList = []
      const codeFiles = this.ruleForm.scriptPath
      const codeArr = JSON.parse(codeFiles)
      this.ruleForm.scriptPath = codeArr
      codeArr.forEach(e => {
        let name = e.indexOf('-') !== -1 ? e.split('-')[1] : e
        name = name.indexOf('/') !== -1 ? name.split('/')[1] : name
        const url = host + '/' + e
        this.codeFileList.push({ name: name, url: url })
      })

      // 回显model file
      const modelFiles = this.ruleForm.modelPath
      const modelArr = JSON.parse(modelFiles)
      this.ruleForm.modelPath = modelArr
      modelArr.forEach(e => {
        let name = e.indexOf('-') !== -1 ? e.split('-')[1] : e
        name = name.indexOf('/') !== -1 ? name.split('/')[1] : name
        const url = host + '/' + e
        this.modelFileList.push({ name: name, url: url })
      })
    }
  }
}
</script>

<style>

.wrapper{
  height: 900px;
  width: 1300px;
  margin: 0px;
  margin-left: 20px;
  border: 0px;
  padding: 0px;
  background: #fff;
}
.my-title{
  background: #eee;
  margin: 0px;
  border: 0px;
  padding: 20px;
  color: #333;
  font-weight: bold;
}
.demo-ruleForm{
  padding: 20px;
}
</style>
