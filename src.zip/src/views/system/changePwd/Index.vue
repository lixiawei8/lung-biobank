<template>
  <div class="wrapper1">
    <div class="change">
      <div class="my-title">修改账户密码</div>
      <div class="demo-ruleForm">
        <el-form :model="ruleForm" :rules="rules" ref="ruleForm">
          <el-form-item label="原始密码" prop="oldPass">
            <el-input type="password" v-model="ruleForm.oldPass" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="新置密码" prop="pass">
            <el-input type="password" v-model="ruleForm.pass" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="确认密码" prop="checkPass">
            <el-input type="password" v-model="ruleForm.checkPass" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="submitForm('ruleForm')">提交</el-button>
            <el-button type="primary" plain @click="resetForm('ruleForm')">重置</el-button>
            <el-button @click="closePage">取消</el-button>
          </el-form-item>
        </el-form>
      </div>
    </div>
  </div>
</template>

<script>
import { mapState, mapMutations } from 'vuex'

export default {
  name: 'MyChangePwd',
  computed: {
    ...mapState('login', ['userInfo']) // login模块
  },
  data () {
    const validatePass = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请输入新密码'))
      } else {
        if (this.ruleForm.checkPass !== '') {
          this.$refs.ruleForm.validateField('checkPass')
        }
        callback()
      }
    }
    const validatePass2 = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请确认新密码'))
      } else if (value !== this.ruleForm.pass) {
        callback(new Error('两次输入密码不一致!'))
      } else {
        callback()
      }
    }
    return {
      pass: '',
      ruleForm: {
        oldPass: '',
        pass: '',
        checkPass: ''
      },
      rules: {
        oldPass: [
          { required: true, message: '请输入原始密码', trigger: 'blur' }
        ],
        pass: [
          { validator: validatePass, trigger: 'blur' },
          { required: true, min: 6, max: 20, message: '新密码长度在 6 到 20 个字符', trigger: 'blur' }
        ],
        checkPass: [
          { required: true, validator: validatePass2, trigger: 'blur' }
        ]
      }
    }
  },
  methods: {
    // 存储修改后的信息
    ...mapMutations('login', ['setUser']),
    // 修改
    async updatePwd (params) { // id pass
      const res = await this.$api.changePwd(params)
      console.log('----------------修改密码res', res.data)
      if (res.data.status === 200) {
        this.pass = params.pass
        this.$message({
          message: '账户密码修改成功！',
          type: 'success'
        })

        this.setUser({
          id: this.userInfo.id,
          uname: this.userInfo.uname,
          pword: this.pass,
          token: this.userInfo.token
        })
        console.log('------------------改密后设置userinfo成功, this.userInfo.pword', this.userInfo.pword)
        this.$router.push('/') // 返回首页
      } else {
        this.$message({
          message: '账户密码修改失败！',
          type: 'error'
        })
      }
    },

    // 提交表单
    submitForm (formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          const { oldPass, pass } = this.ruleForm
          console.log('------------------修改账户密码, ruleForm', this.ruleForm)
          const id = this.userInfo.id

          if (oldPass !== this.userInfo.pword) {
            this.$message({
              message: '原密码输入错误',
              type: 'error'
            })
            return false
          }
          if (pass === this.userInfo.pword) {
            this.$message({
              message: '新置密码与原始密码相同',
              type: 'error'
            })
            return false
          }
          this.updatePwd({ id, pass })
        } else {
          console.log('error submit!')
          return false
        }
      })
    },

    // 重置表单
    resetForm (formName) { // 清空数据
      this.$refs[formName].resetFields()
    },

    // 关闭页面
    closePage () {
      this.$router.push('/')
    }
  },
  mounted () {
  }
}
</script>

<style>

.wrapper1{
  height: 900px;
  width: 1200px;
  border-top: 100px;
  background: #fff;
  margin: 0px;
  border: 0px;
  padding: 0px;
}
.demo-ruleForm {
  padding: 20px;
  padding-top: 200px;
  padding-left: 250px;
  width: 600px;
  text-align: center !important;
}
.change{
  padding: 20px;
}
.my-title{
  background: #eee;
  margin: 0px;
  border: 0px;
  padding: 10px;
  color: #333;
  font-weight: bold;
}

</style>
