<template>
  <div>
      <!-- 数据搜索 -->
      <div class="header">
        <div class="form">
          <el-form :inline="true" :model="formInline" class="demo-form-inline">
            <el-form-item label="患者编号">
              <el-input v-model="formInline.modelId" size="big" @blur="blur" placeholder="患者编号"></el-input>
            </el-form-item>
            <el-form-item label="关键词">
              <el-input v-model="formInline.modelKey" size="big" @blur="blur" placeholder="关键词" class="border-input"></el-input>
            </el-form-item>
            <el-form-item>
              <el-button type="primary" size="big" icon="el-icon-search" @click="searchHandle"></el-button>
            </el-form-item>
          </el-form>
        </div>
        <div class="multi-btn">
          <el-row>
            <el-button size="big" type="warning" @click="addHandle" icon="el-icon-plus">新增记录</el-button>
            <el-button size="big" type="danger" @click="deleteBatchHandle" icon="el-icon-delete">批量删除</el-button>
          </el-row>
        </div>
      </div>
      <!-- 数据列表 -->
      <div class="content-wrapper">
        <div class="content">
          <el-table :data="tableData" style="width: 100%;" stripe border header-cell-class-name="active-header"
            cell-class-name="table-left" @select="selectHandle" @select-all="selectAllHandle">
            <el-table-column type="selection" width="55">
            </el-table-column>
            <el-table-column prop="id" label="编号" width="50">
            </el-table-column>
            <el-table-column prop="name" label="数据名称" width="150" show-overflow-tooltip>
              <template slot-scope="scope">
                <span style="color:#0c64c1;cursor:pointer" @click="detailHandle(scope.$index, scope.row)">{{ scope.row.name }}</span>
              </template>
            </el-table-column>
            <el-table-column prop="category" label="数据类别" width="100">
            </el-table-column>
            <el-table-column prop="createTime" label="创建时间" width="150">
              <template slot-scope="scope">
                <span>{{ dayjs(scope.row.createTime).format('YYYY-MM-DD HH:mm:ss') }}</span>
              </template>
            </el-table-column>
            <el-table-column prop="feature" label="数据特点" width="220" show-overflow-tooltip>
            </el-table-column>
            <el-table-column prop="description" label="数据描述" width="380" show-overflow-tooltip>
              <template slot-scope="scope">
                <span>{{ removeHTMLTag(scope.row.description) }}</span>
              </template>
            </el-table-column>

            <el-table-column label="操作" width="280">
              <template slot-scope="scope">
                <el-button size="mini" type="primary" @click="editHandle(scope.$index, scope.row)" icon="el-icon-edit">编辑</el-button>
                <el-button size="mini" type="danger" @click="deleteHandle(scope.$index, scope.row)" icon="el-icon-delete">删除</el-button>
              </template>
            </el-table-column>
          </el-table>
          <div class="pagination">
            <MyPagination :total="total" :pageSize="pageSize"></MyPagination>
          </div>
        </div>
      </div>
  </div>
</template>

<script>
import MyPagination from '@/components/pagination/Pagination.vue'
import dayjs from 'dayjs'
import { removeHTMLTag } from '@/utils/common.js' // 对象格式
import { mapMutations } from 'vuex'
export default {
  name: 'MyDataGeneList',
  components: {
    MyPagination
  },
  data () {
    return {
      category: 'gene',
      formInline: {
        modelId: '',
        modelKey: ''
      },
      tableData: [],
      total: 1, // 总记录数
      pageSize: 1, // 每页记录数 最多存100记录/page
      ids: [] // ids数组
    }
  },
  methods: {
    // 轻量级时间格式包
    dayjs,
    // 清除html标记
    removeHTMLTag,
    ...mapMutations('model', ['changeTitle', 'changeData']), // model: module, changeData方法
    // 选择事件
    selectHandle (selection) {
      console.log('---------- selectHandle sel', selection)
      const arr = []
      selection.forEach(e => {
        arr.push(e.id)
      })
      this.ids = arr
    },
    // 全选事件
    selectAllHandle (selection) {
      console.log('---------- selectAllHandle', selection)
    },

    // 数据列表 不分页
    async modelList () {
      console.log('-------------[基因数据列表 category]', this.category)
      const res = await this.$api.modelList({ category: this.category })
      console.log('-------------基因数据列表 res', res)
      this.tableData = res.data.data
      this.total = res.data.total
      this.pageSize = res.data.pageSize
    },
    // 失去焦点时操作
    blur () {
      console.log('-------搜索失去焦点, this.formInline.modelId', this.formInline.modelId, ' this.formInline.modelKey', this.formInline.modelKey)
      if (!this.formInline.modelId && !this.formInline.modelKey) {
        this.modelList()
      }
    },

    // 搜索数据 async
    async search (modelId, modelKey) {
      if (!modelId && !modelKey) {
        return
      }
      console.log('---------gene list modelId', modelId, ', modelKey', modelKey)
      const res = await this.$api.search({ modelId, modelKey })
      console.log('---------搜索结果', res.data)
      if (res.data.status === 200) {
        this.tableData = res.data.data
        this.total = res.data.total
        this.pageSize = res.data.pageSize
      } else {
        console.log('--------msg', res.data.msg)
        this.tableData = []
        this.total = 1
        this.pageSize = 1
      }
    },
    // 通过编号/名称搜索
    searchHandle () {
      console.log('---------submit modelId: ', this.formInline.modelId)
      this.search(this.formInline.modelId, this.formInline.modelKey)
    },

    // 新增
    addHandle () {
      console.log('--------addHandle')
      this.changeTitle('添加')
      this.$router.push('/gene/page')
    },

    // run
    detailHandle (index, row) {
      console.log('------------detailHandle, index ', index, 'row ', row)
      this.changeData(row) // 渲染数据
      this.$router.push('/gene/run')
    },

    // 信息编辑
    editHandle (index, row) {
      console.log('------------editHandle, index ', index, 'row ', row)
      // 获取当前行数据--vuex--跳转到另一界面获取vuex数据
      this.changeTitle('编辑')
      this.changeData(row)
      // 跳转编辑界面
      this.$router.push('/gene/page')
    },

    // 单条数据删除接口 async
    async delete (id) {
      // console.log('----删除id', id)
      const res = await this.$api.deleteItemById({ id })
      console.log('----删除 res', res.data)
      if (res.data.status === 200) {
        this.$message({
          type: 'success',
          message: '删除成功!'
        })
        this.modelList()
      } else {
        this.$message({
          type: 'error',
          message: '删除失败!'
        })
      }
    },
    // 单条数据删除
    deleteHandle (index, row) {
      console.log('----删除操作', index, row)
      this.$confirm('确定删除该数据记录?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.delete(row.id)
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '取消删除。'
        })
      })
    },

    // 批量删除接口 async
    async deleteBatch () {
      const res = await this.$api.deleteItemByIds({ ids: this.ids })
      console.log('----批量删除 res', res.data)
      if (res.data.status === 200) {
        this.$message({
          type: 'success',
          message: '批量删除成功!'
        })
        this.modelList()
      } else {
        this.$message({
          type: 'error',
          message: '批量删除失败!'
        })
      }
    },
    // 批量删除
    deleteBatchHandle () {
      console.log('----批量删除操作')
      this.$confirm('确定批量删除?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.deleteBatch()
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '取消批量删除。'
        })
      })
    }
  },
  created () { // 生命周期函数
    console.log('获取当前的时间', new Date(), dayjs().format('YYYY-MM-DD HH:mm:ss'))
    this.modelList()
  }
}
</script>

<style lang="less" scoped>
.header{
  background: #fff;
  margin-bottom: 20px;
  margin-left: 80px;
  width: 1400px;
  .el-form-item{
    margin: 10px;
  }
  .multi-btn{
    margin: 5px;
  }
  .border-input{
    width: 500px
  }
}
.content-wrapper{
  height: 800px;
  margin-left: 80px;
  background: #fff;
}
.content{
  background: #fff;
  padding: 10px;
  width: 1300px;
  /deep/ .active-header{
    color: #333;
    text-align: center;
  }
  /deep/ .table-left{
    text-align: left;
  }
  .pagination{
    padding: 10px;
    text-align: center;
  }
}
</style>
