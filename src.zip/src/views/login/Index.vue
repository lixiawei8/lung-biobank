<template>
    <div class="clearfix" id="login_wrap">
      <div class="login">
        <h2 class="title">登录页面</h2>
          <div class="login-account">
            <span>账号：</span>
            <input type="text" placeholder="请输入账号" name="account" v-model.trim="username"/>
          </div>
          <div class="login-password">
            <span>密码：</span>
            <input type="password" placeholder="请输入密码" name="password" v-model.trim="password"/>
          </div>
          <p class="login-btn">
            <el-button id="loginBtn" type="primary" @click="login">登录</el-button>
          </p>
          <!-- <p class="info"> admin/123: 管理员</p> -->
      </div>
    </div>
</template>

<script>
import { mapMutations } from 'vuex'
export default {
  name: 'MyLogin',
  data () {
    return {
      username: '',
      password: ''
    }
  },
  methods: {
    ...mapMutations('login', ['setUser']),
    // 1 获取输入内容；2 请求接口；3 请求成功-存储登录信息-进入首页
    async login () {
      console.log('------------------ 1在登陆页 登录接口请求开始')
      const res = await this.$api.login({
        user: this.username,
        pwd: this.password
      })
      if (res.data.status === 200) {
        console.log('------------------- 登录接口请求成功, res[0]', res.data.result[0])
        // 存储登录信息
        this.setUser({
          id: res.data.result[0].id,
          uname: this.username,
          pword: this.password,
          token: res.data.token
        })
        // 登录成功进入首页
        this.$router.push('/')
      } else {
        this.$message.warning(res.data.msg)
      }
    }
  }
}
</script>

<style lang="less" scoped>
.title{
    text-align: center;
    font-size: 22px;
}
#login_wrap{
    position: relative;
    background: rgba(64, 64, 194, 0.1);
    height: 100%;
    > div {
        background: #fff;
        width: 420px;
        height: 300px;
        padding: 30px 40px;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        > div {
        padding: 10px 0;

        &.login-account {
            margin: 25px 0 30px;
        }
        span {
            color: #666;
            display: inline-block;
            width: 84px;
            font-size: 20px;
        }
        input {
            background: none;
            font-size: 16px;
            border: none;
            height: 30px;
            width: 280px;
            padding-left: 12px;
            box-sizing: border-box;
            color: #666;
            &.error {
            border: 1px solid #f00;
            }
            &::-webkit-input-placeholder {
            color: #aaa;
            }
        }
        }
        p {
        text-align: right;
        &.login-btn {
            button {
            width: 100%;
            height: 50px;
            font-size: 18px;
            margin-top: 30px;
            }
        }
        a {
            color: #fff;
            display: inline-block;
            padding: 0 15px;
            font-size: 14px;
        }
        }
    }
}
.info{
    color: #999;
    margin-top: 8px;
    text-align: right;
}
</style>
